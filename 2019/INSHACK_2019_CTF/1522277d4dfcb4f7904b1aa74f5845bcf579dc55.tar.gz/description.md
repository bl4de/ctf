Signed or not signed, this is the question :)

[Binary](https://static.ctf.insecurity-insa.fr/1522277d4dfcb4f7904b1aa74f5845bcf579dc55.tar.gz)

`ssh -i <your_keyfile> -p 2228 user@signed-or-not-signed.ctf.insecurity-insa.fr`
To find your keyfile, look into your profile on this website.

[https://www.youtube.com/watch?v=inXC_lab-34](https://www.youtube.com/watch?v=inXC_lab-34)
