I recently discover this file called `Test.CBL`. It seems to be a small service aiming at storing the result of babyfoot matchs between interns at the INSHACK BANK. Maybe you can break into the MAINFRAME.

You can found the [source code here](https://static.ctf.insecurity-insa.fr/a646237a9e68c8f1e1016d9e6376c2cc49745288.tar.gz) and you can connect to the MAINFRAME here: `ssh -i <your_keyfile> -p 2224 user@overcobol.ctf.insecurity-insa.fr`
To find your keyfile, look into your profile on this website.

[https://www.youtube.com/watch?v=HXvm76e2X1Q](https://www.youtube.com/watch?v=HXvm76e2X1Q)