const globalVars = {
  TITLE: "My First App!",
  SECRET: "here is my secret: https://www.youtube.com/watch?v=jIQ6UV2onyI",
  FLAG: "FLAGFLAGFLAG",
};

export default globalVars;
