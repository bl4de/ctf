#include <stdlib.h>
#include <stdio.h>

void win() {
    system("/bin/sh");
}

void main() {
    char buff[69];

    gets(buff);
}